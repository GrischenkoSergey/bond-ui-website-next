"use client"

import Layout from "@/components/Layout"

export default function Terms() {
  return (
    <Layout pageId="terms">
      <div className="terms-content">
        <h1>Terms and Conditions</h1>
        <p>Terms content goes here...</p>
      </div>
    </Layout>
  )
}

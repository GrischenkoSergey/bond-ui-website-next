"use client"

import Layout from "@/components/Layout"

export default function RefundPolicy() {
  return (
    <Layout pageId="refundpolicy">
      <div className="refund-content">
        <h1>Refund Policy</h1>
        <p>Refund policy content goes here...</p>
      </div>
    </Layout>
  )
}

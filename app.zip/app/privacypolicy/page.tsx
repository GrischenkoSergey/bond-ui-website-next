"use client"

import Layout from "@/components/Layout"

export default function PrivacyPolicy() {
  return (
    <Layout pageId="privacypolicy">
      <div className="privacy-content">
        <h1>Privacy Policy</h1>
        <p>Privacy policy content goes here...</p>
      </div>
    </Layout>
  )
}

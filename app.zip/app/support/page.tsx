"use client"

import Layout from "@/components/Layout"

export default function Support() {
  return (
    <Layout pageId="support">
      <div className="support-content">
        <h1>Support</h1>
        <p>Support information goes here...</p>
      </div>
    </Layout>
  )
}

import Home from "./home/page"

export default function RootPage() {
  return <Home />
}

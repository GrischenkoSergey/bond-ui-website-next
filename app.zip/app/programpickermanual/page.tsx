"use client"

import Layout from "@/components/Layout"

export default function ProgramPickerManual() {
  return (
    <Layout pageId="programpickermanual">
      <div className="manual-content">
        <h1>Program Picker Manual</h1>
        <p>Manual content goes here...</p>
      </div>
    </Layout>
  )
}
